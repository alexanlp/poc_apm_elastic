﻿using Elastic.Apm;
using Elastic.Apm.DiagnosticSource;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;

namespace APMMVC.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            //var ramdom = new Random().Next(1000, 3000);
            //System.Threading.Thread.Sleep(ramdom);

            return View();
        }

        [Route("{cod}")]
        public async Task<ActionResult> About(string cod)
        {
            //var ramdom = new Random().Next(1000, 3000);
            //System.Threading.Thread.Sleep(ramdom);
            
            ViewBag.Message = "Your application description page.";
            
            //Agent.Subscribe(new HttpDiagnosticsSubscriber());

            //await Agent.Tracer.CaptureTransaction("SampeApp", "Request", async () =>
            //{
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri("http://localhost:64080/");
                ViewBag.Json = await client.GetStringAsync("api/values");
            //});
            


            //var restClient = new RestClient("http://localhost:64080/");
            //var request = new RestRequest("api/values", Method.GET, DataFormat.Json);
            //var result = restClient.Execute(request);

            //ViewBag.Json = result.Content;


            return View();
        }

        public ActionResult Contact()
        {
            var ramdom = new Random().Next(1000, 2500);
            System.Threading.Thread.Sleep(ramdom);

            throw new Exception("Erro");
            ViewBag.Message = "Your contact page.";

            return View();
        }
    }
}